from typing import Tuple
import numpy as np
import spatialmath as sm
import spatialmath.base as smb
import roboticstoolbox as rtb
import sympy as sym


# --------- Question 1.1 ---------- #

def is_twist(twist: np.ndarray) -> bool:
    """
    Check if a numpy array is a twist

    A valid twist has the shape (6,) with contents [v1, v2, v3, eta1, eta2, eta3]
    Note that shape (6,) is different from shape (6, 1)

    Parameters
    ----------
    twist
        The vector to check

    Returns
    -------
    bool
        True if the vector is a twist, False otherwise

    """

    # Your code goes here
    pass


# --------- Question 1.2 ---------- #

def SE3_to_twist(T: np.ndarray) -> np.ndarray:
    """
    Convert an 4x4 numpy array representing an SE3 matrix to a twist

    Parameters
    ----------
    T
        A (4, 4) numpy array representing an SE3 matrix

    Returns
    -------
    twist
        The twist representation of the SE3 as a numpy
        array: [v1, v2, v3, eta1, eta2, eta3]

    """

    # Your code goes here
    pass


# --------- Question 1.3 ---------- #

def twist_to_SE3(twist: np.ndarray) -> np.ndarray:
    """
    Convert a twist to an SE3 matrix

    Parameters
    ----------
    twist
        The twist representation of the SE3 object as a numpy
        array: [v1, v2, v3, eta1, eta2, eta3]

    Returns
    -------
    T
        The SE3 matrix as a (4, 4) numpy array

    """

    # Your code goes here
    pass


# --------- Question 2.1 ---------- #

def SE3_twist_traj(wTa: sm.SE3, wTb: sm.SE3, n: int) -> sm.SE3:
    """
    Compute the trajectory between two poses

    Computes the trajectory between two poses using a quintic polynomial
    profile taking `n` steps.

    The trajectory is to be calculated using the twist representation of the pose.

    The calculated trajectory is then converted back to an SE3 representation and
    stored in a SE3 object. This means that you create an sm.SE3.Empty() object and keep 
    appending new SE3 objects to it.

    Hint
    ----
    1. Explore the `roboticstoolbox` method `mtraj` 
    2. SE3 objects are part of the `spatialmath` package. An SE3 object is not a 4x4 numpy array.

    Parameters
    ----------
    wTa
        The start pose in the world frame given as an SE3 object
    wTb
        The end pose in the world frame given as an SE3 object
    n
        The number of steps in the trajectory

    Returns
    -------
    traj
        A SE3 object containing the trajectory

    """

    # Your code goes here
    pass


# --------- Question 2.2 ---------- #

def SE3_traj_relative(traj_world: sm.SE3) -> sm.SE3:
    """
    Converts a trajectory in the world frame to relative frames

    Given a trajectory in the world frame (each pose in the trajectory is
    relative to the world frame) this function converts the trajectory to
    a relative frame (each pose in the trajectory is relative to the previous
    pose in the trajectory).

    The first pose in the trajectory is ignored as it has no previous pose
    to be relative to. The returned trajectory will be of length n - 1 where
    n is the length of `traj_world`.

    Parameters
    ----------
    traj_world
        A SE3 object containing the trajectory in the world frame

    Returns
    -------
    traj_relative
        A SE3 object containing the trajectory in the relative frame

    """

    # Your code goes here
    pass


# --------- Question 3.1 ---------- #

def quintic_properties_symbolic(
    coeffs: Tuple[float, float, float, float, float, float]
) -> Tuple[float, float]:
    """
    Extract the maximum acceleration and jerk from a quintic polynomial

    Given the coefficients of a quintic polynomial, this function extracts
    the maximum acceleration and jerk from the trajectory between t=0 and t=1.

    Hint
    ----
    1. The Python package sympy may be helpful for this question.
    2. Look for the global maximum of the acceleration and jerk.
    3. Consider the absolute values of the acceleration and jerk.

    Parameters
    ----------
    coeffs
        The coefficients of the quintic polynomial in the form
        [A, B, C, D, E, F] where the polynomial is defined as
        q(t) = At^5 + Bt^4 + Ct^3 + Dt^2 + Et + F

    Returns
    -------
    maximums
        A Tuple containing the maximum absolute value of acceleration and
        jerk respectively

    """

    # Your code goes here
    pass


# --------- Question 4.1 ---------- #

def rocket_diagnostics(traj: sm.SE3, T: sm.SE3) -> float:
    """
    Find the time at which a rocket reaches a pose

    Given a trajectory `traj` for a rocket, this function finds the time at which
    the rocket reaches a given pose `T`. 
    
    Assume that the time between each pose in the trajectory is constant at 0.5 seconds.
    The trajectory is provided in relative form where each pose is relative to the previous pose. 
    The first pose in the trajectory is relative to the world frame. 
    The pose `T` is provided in the world frame.

    The maximum absolute tolerance of each element of `T` and the matched pose within
    `traj` is 1e-4.

    Parameters
    ----------
    traj
        A SE3 object containing the trajectory of the rocket
    T
        The pose to find the time for

    Returns
    -------
    time
        The time at which the rocket reaches the pose `T`

    """

    # Your code goes here
    pass

# --------- Question 4.2 ---------- #

def rocket_pose(traj: sm.SE3, wTa: sm.SE3) -> Tuple[sm.SE3, float]:
    """
    Given a trajectory and the pose of the rocket at some time wrt the world frame, 
    find the pose of the goal frame with respect to the rocket frame, 
    and the time taken by the rocket to complete the remainder of the trajectory.

    The frames are defined as follows:

    - {w} is the world frame (the pose of the rocket at traj[0])
    - {a} is the frame of the rocket at some time during the trajectory
    - {g} is the goal frame (the pose of the rocket at traj[-1])

    The pose `wTa` represents the frame {a} relative to {w}.
    This function finds the relative pose `aTg` and the time taken for the rocket
    to complete the remainder of the trajectory. You can assume that the time
    between each pose in the trajectory is constant at 0.5 seconds. Each pose in
    the trajectory is given in the world frame. The pose `aTg` is the pose of the
    rocket at the goal {g} relative to {a}. `traj[0]` occurs at time 0.

    The maximum absolute tolerance of each element of `wTa` and the matched pose within
    `traj` is 1e-8.

    Parameters
    ----------
    traj
        An SE3 object containing the trajectory of the rocket in the world frame
    wTa
        The pose of frame {a} relative to {w}

    Returns
    -------
    aTg
        The pose of the rocket at the goal {g} relative to {a}
    time
        The time taken for the rocket to complete the aTg segment of the
        trajectory

    """

    # Your code goes here
    pass
        
